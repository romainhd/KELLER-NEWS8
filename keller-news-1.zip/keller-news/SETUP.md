# KELLER NEWS — Setup

Eine Codebasis, beide Plattformen (Expo / React Native).
Leser: kein Login. Redaktion: ein Konto mit Schreibrecht.

## 1. Starten

```
npm install
npx expo start
```

QR-Code mit der **Expo Go** App scannen (iPhone + Android).
Läuft sofort im Demo-Modus: Login-Passwort `keller`, alles bleibt nur im Speicher.

## 2. Backend anlegen (Supabase, kostenlos)

Projekt auf supabase.com anlegen, dann im **SQL Editor** ausführen:

```sql
-- Meldungen
create table posts (
  id uuid primary key default gen_random_uuid(),
  kicker text not null default 'Meldung',
  title text not null,
  sector text,
  lead text,
  body text not null,
  created_at timestamptz not null default now()
);

-- Kommentare
create table comments (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references posts(id) on delete cascade,
  name text not null default 'Anonym',
  text text not null,
  created_at timestamptz not null default now()
);

alter table posts enable row level security;
alter table comments enable row level security;

-- Lesen: alle. Schreiben: nur angemeldete Redaktion.
create policy "posts lesen"      on posts for select using (true);
create policy "posts schreiben"  on posts for insert to authenticated with check (true);
create policy "posts ändern"     on posts for update to authenticated using (true);
create policy "posts löschen"    on posts for delete to authenticated using (true);

-- Kommentieren: alle, ohne Login. Löschen: nur Redaktion.
create policy "kommentare lesen"  on comments for select using (true);
create policy "kommentare senden" on comments for insert with check (
  char_length(text) between 1 and 1200 and char_length(name) <= 40
);
create policy "kommentare löschen" on comments for delete to authenticated using (true);

create index on comments (post_id, created_at);
create index on posts (created_at desc);
```

## 3. Admin-Konto anlegen

Supabase → **Authentication → Users → Add user**: E-Mail und Passwort setzen,
Haken bei *Auto Confirm User*.

Wichtig: Unter **Authentication → Providers → Email** die Selbstregistrierung
abschalten (*Allow new users to sign up* aus). Sonst kann sich jeder ein Konto
anlegen und schreiben.

## 4. App verbinden

`src/config.js` öffnen, **Project URL** und **anon public key** eintragen
(Supabase → Project Settings → API). Fertig.

## 5. Bedienung

- **Anmelden:** langer Druck auf den Schriftzug KELLER NEWS im Kopfbereich.
- **Schreiben:** angemeldet erscheint oben die Leiste *+ Neue Meldung*.
- **Ändern/Löschen:** Meldung öffnen → *Bearbeiten*.
- **Kommentare moderieren:** angemeldet steht neben jedem Kommentar *Entfernen*.
- **Abmelden:** in der Redaktionsleiste über der Meldungsliste.

Die Anmeldung bleibt gespeichert, bis du abmeldest.

## 6. Kopfbild

`assets/header.jpg` überschreiben (quer, ca. 1400×1000). Aktuell liegt dort ein
Platzhalter.

## 7. In die Stores

```
npm install -g eas-cli
eas build --platform android
eas build --platform ios
```

Voraussetzung: Apple Developer Program (99 $/Jahr), Google Play Console (25 $ einmalig).

## Aufbau

```
App.js                       Navigation, dunkles Theme, HUD-Rahmen
src/config.js                Supabase-Zugangsdaten  ← hier eintragen
src/auth.js                  Admin-Anmeldung, gespeicherte Sitzung
src/api.js                   Meldungen + Kommentare
src/store.js                 App-Zustand (Sitzung, Meldungen)
src/theme.js                 Farben, Typografie, Abstände
src/posts.js                 Startbestand für den Demo-Modus
src/screens/FeedScreen.js    Kopfbild, Meldungsliste, Redaktionsleiste
src/screens/PostScreen.js    Einzelmeldung
src/screens/LoginScreen.js   Anmeldung
src/screens/EditorScreen.js  Meldung schreiben, ändern, löschen
src/components/Comments.js   Kommentare
src/ui/Frame.js              Eckwinkel-Rahmen über allem
```
