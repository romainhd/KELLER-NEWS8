import React from 'react';
import { View, StatusBar } from 'react-native';
import { NavigationContainer, DarkTheme } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { SafeAreaProvider } from 'react-native-safe-area-context';

import FeedScreen from './src/screens/FeedScreen';
import PostScreen from './src/screens/PostScreen';
import LoginScreen from './src/screens/LoginScreen';
import EditorScreen from './src/screens/EditorScreen';
import Frame from './src/ui/Frame';
import { AppProvider } from './src/store';
import { C } from './src/theme';

const Stack = createNativeStackNavigator();

const theme = {
  ...DarkTheme,
  colors: {
    ...DarkTheme.colors,
    background: C.void,
    card: C.void,
    text: C.text,
    border: C.hairline,
    primary: C.holo,
  },
};

export default function App() {
  return (
    <SafeAreaProvider>
      <AppProvider>
        <View style={{ flex: 1, backgroundColor: C.void }}>
          <StatusBar barStyle="light-content" backgroundColor={C.void} />
          <NavigationContainer theme={theme}>
            <Stack.Navigator
              screenOptions={{
                headerShown: false,
                contentStyle: { backgroundColor: C.void },
                animation: 'fade',
              }}
            >
              <Stack.Screen name="Feed" component={FeedScreen} />
              <Stack.Screen name="Post" component={PostScreen} />
              <Stack.Screen
                name="Login"
                component={LoginScreen}
                options={{ animation: 'slide_from_bottom' }}
              />
              <Stack.Screen
                name="Editor"
                component={EditorScreen}
                options={{ animation: 'slide_from_bottom' }}
              />
            </Stack.Navigator>
          </NavigationContainer>
          <Frame />
        </View>
      </AppProvider>
    </SafeAreaProvider>
  );
}
