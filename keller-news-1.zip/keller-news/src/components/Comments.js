import React, { useEffect, useState, useCallback } from 'react';
import {
  View,
  Text,
  TextInput,
  Pressable,
  ActivityIndicator,
  Alert,
  StyleSheet,
} from 'react-native';
import { loadComments, sendComment, deleteComment } from '../api';
import { isLive } from '../config';
import { useApp } from '../store';
import { fmtStamp } from '../format';
import { C, S, MONO, display, data, body } from '../theme';

export default function Comments({ postId }) {
  const { isAdmin, session } = useApp();
  const [items, setItems] = useState([]);
  const [status, setStatus] = useState('loading');
  const [name, setName] = useState('');
  const [text, setText] = useState('');
  const [sending, setSending] = useState(false);
  const [sendError, setSendError] = useState(null);

  const fetchAll = useCallback(async () => {
    setStatus('loading');
    try {
      setItems(await loadComments(postId));
      setStatus('ready');
    } catch {
      setStatus('failed');
    }
  }, [postId]);

  useEffect(() => {
    fetchAll();
  }, [fetchAll]);

  const submit = async () => {
    if (!text.trim() || sending) return;
    setSending(true);
    setSendError(null);
    try {
      const created = await sendComment(postId, name, text);
      setItems((prev) => [...prev, created]);
      setText('');
    } catch {
      setSendError('Nicht gesendet. Verbindung prüfen und erneut senden.');
    } finally {
      setSending(false);
    }
  };

  const remove = (id) => {
    Alert.alert('Kommentar entfernen', 'Der Eintrag verschwindet dauerhaft.', [
      { text: 'Abbrechen', style: 'cancel' },
      {
        text: 'Entfernen',
        style: 'destructive',
        onPress: async () => {
          try {
            await deleteComment(session.token, id);
            setItems((prev) => prev.filter((c) => c.id !== id));
          } catch {
            Alert.alert('Nicht entfernt', 'Erneut versuchen.');
          }
        },
      },
    ]);
  };

  return (
    <View style={s.wrap}>
      <View style={s.head}>
        <Text style={display(13, C.text)}>Übertragungen</Text>
        <Text style={data(10, C.textDim)}>
          {status === 'ready' ? String(items.length).padStart(3, '0') : '···'}
        </Text>
      </View>

      {status === 'loading' && (
        <View style={s.state}>
          <ActivityIndicator color={C.holo} />
        </View>
      )}

      {status === 'failed' && (
        <View style={s.state}>
          <Text style={body(15, C.alert)}>
            Das Relais antwortet nicht. Die Meldung selbst ist vollständig.
          </Text>
          <Pressable onPress={fetchAll} hitSlop={10}>
            <Text style={[data(11, C.holo), s.retry]}>Erneut laden</Text>
          </Pressable>
        </View>
      )}

      {status === 'ready' && items.length === 0 && (
        <View style={s.state}>
          <Text style={body(15, C.textDim)}>
            Noch nichts eingegangen. Sag du zuerst etwas.
          </Text>
        </View>
      )}

      {status === 'ready' &&
        items.map((c) => (
          <View key={c.id} style={s.item}>
            <View style={s.itemHead}>
              <Text style={data(10, C.holo)}>{c.name || 'Anonym'}</Text>
              <View style={s.itemRight}>
                <Text style={data(10, C.textDim)}>{fmtStamp(c.created_at)}</Text>
                {isAdmin && (
                  <Pressable onPress={() => remove(c.id)} hitSlop={10}>
                    <Text style={data(10, C.alert)}>Entfernen</Text>
                  </Pressable>
                )}
              </View>
            </View>
            <Text style={body(15)}>{c.text}</Text>
          </View>
        ))}

      <View style={s.form}>
        <Text style={[data(10, C.textDim), s.formLabel]}>Antworten</Text>
        <TextInput
          value={name}
          onChangeText={setName}
          placeholder="Name (frei lassen für Anonym)"
          placeholderTextColor={C.textDim}
          style={s.input}
          maxLength={40}
        />
        <TextInput
          value={text}
          onChangeText={setText}
          placeholder="Deine Nachricht"
          placeholderTextColor={C.textDim}
          style={[s.input, s.inputMulti]}
          multiline
          maxLength={1200}
        />
        {sendError && (
          <Text style={[body(13, C.alert), s.sendError]}>{sendError}</Text>
        )}
        <Pressable
          onPress={submit}
          disabled={!text.trim() || sending}
          style={({ pressed }) => [
            s.button,
            (!text.trim() || sending) && s.buttonOff,
            pressed && s.buttonPressed,
          ]}
        >
          <Text style={data(11, text.trim() ? C.crawl : C.textDim)}>
            {sending ? 'Wird gesendet…' : 'Senden'}
          </Text>
        </Pressable>
        {!isLive() && (
          <Text style={[data(9, C.textDim), s.demo]}>
            Demo-Modus · nur bis zum Schließen der App
          </Text>
        )}
      </View>
    </View>
  );
}

const s = StyleSheet.create({
  wrap: {
    marginTop: S.xl,
    paddingHorizontal: S.lg,
    paddingTop: S.lg,
    borderTopWidth: 1,
    borderTopColor: C.hairlineHi,
  },
  head: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: S.lg,
  },
  state: { paddingVertical: S.lg },
  retry: { marginTop: S.md },
  item: {
    paddingVertical: S.md,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: C.hairline,
  },
  itemHead: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: S.sm,
  },
  itemRight: { flexDirection: 'row', alignItems: 'center', gap: S.md },
  form: {
    marginTop: S.xl,
    backgroundColor: C.panel,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: C.hairline,
    padding: S.md,
  },
  formLabel: { marginBottom: S.md },
  input: {
    fontFamily: MONO,
    fontSize: 14,
    color: C.text,
    backgroundColor: C.void,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: C.hairline,
    paddingHorizontal: S.md,
    paddingVertical: S.sm + 2,
    marginBottom: S.sm,
  },
  inputMulti: { minHeight: 96, textAlignVertical: 'top' },
  sendError: { marginBottom: S.sm },
  button: {
    alignItems: 'center',
    paddingVertical: S.md,
    borderWidth: 1,
    borderColor: C.crawl,
  },
  buttonOff: { borderColor: C.hairline },
  buttonPressed: { backgroundColor: C.panelHi },
  demo: { marginTop: S.md, textAlign: 'center' },
});
