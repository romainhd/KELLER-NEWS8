import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  useCallback,
} from 'react';
import { loadPosts } from './api';
import { restoreSession, signIn, signOut } from './auth';

const Ctx = createContext(null);
export const useApp = () => useContext(Ctx);

export function AppProvider({ children }) {
  const [session, setSession] = useState(null);
  const [posts, setPosts] = useState([]);
  const [status, setStatus] = useState('loading'); // loading | ready | failed

  const refresh = useCallback(async () => {
    setStatus('loading');
    try {
      setPosts(await loadPosts());
      setStatus('ready');
    } catch {
      setStatus('failed');
    }
  }, []);

  useEffect(() => {
    restoreSession().then(setSession).catch(() => setSession(null));
    refresh();
  }, [refresh]);

  const login = async (email, password) => {
    const s = await signIn(email, password);
    setSession(s);
    return s;
  };

  const logout = async () => {
    await signOut();
    setSession(null);
  };

  return (
    <Ctx.Provider
      value={{
        session,
        isAdmin: Boolean(session),
        login,
        logout,
        posts,
        status,
        refresh,
        getPost: (id) => posts.find((p) => p.id === id),
      }}
    >
      {children}
    </Ctx.Provider>
  );
}
