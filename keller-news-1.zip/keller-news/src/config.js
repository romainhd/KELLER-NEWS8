// ─────────────────────────────────────────────────────────────
//  Zugangsdaten: Supabase → Project Settings → API
//  Solange leer, läuft alles im Demo-Modus (nur im Speicher).
//  Demo-Login: beliebige E-Mail, Passwort "keller"
// ─────────────────────────────────────────────────────────────

export const SUPABASE_URL = ''; // z. B. 'https://abcdefgh.supabase.co'
export const SUPABASE_ANON_KEY = ''; // "anon public" Schlüssel

export const isLive = () => Boolean(SUPABASE_URL && SUPABASE_ANON_KEY);

export const restHeaders = (token) => ({
  apikey: SUPABASE_ANON_KEY,
  Authorization: `Bearer ${token || SUPABASE_ANON_KEY}`,
  'Content-Type': 'application/json',
  Prefer: 'return=representation',
});
