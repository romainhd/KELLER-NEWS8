// ─────────────────────────────────────────────────────────────
//  Startbestand für den Demo-Modus.
//  Sobald Supabase eingetragen ist, kommen alle Meldungen aus
//  der Datenbank und werden im Editor der App geschrieben.
//  Absätze werden durch Leerzeilen getrennt.
// ─────────────────────────────────────────────────────────────

export const SEED_POSTS = [
  {
    id: 'seed-431',
    kicker: 'Meldung',
    title: 'Das Licht im Treppenhaus bleibt an',
    sector: 'Sektor 07',
    created_at: '2186-03-14T21:40:00.000Z',
    lead: 'Seit vierzehn Nächten schaltet die Automatik nicht mehr ab. Niemand hat sie angefasst.',
    body: `Die Bewegungsmelder im Treppenhaus melden Aktivität, obwohl das Haus leer ist. Der Hausmeister hat den Kasten geöffnet, die Sicherung gezogen, gewartet, wieder eingesetzt. Nach elf Minuten ging das Licht von selbst wieder an.

Der Wartungsdienst spricht von einem Fehler in der Sensorschleife. Die Bewohner im dritten Stock sagen, sie hätten Schritte gehört.

Wir bleiben dran.`,
  },
  {
    id: 'seed-430',
    kicker: 'Protokoll',
    title: 'Neuvermessung der unteren Ebenen',
    sector: 'Sektor 02',
    created_at: '2186-03-09T18:12:00.000Z',
    lead: 'Die alten Pläne stimmen nicht. Sie haben nie gestimmt.',
    body: `Bei der Vermessung des Kellergeschosses wurden zwei Räume erfasst, die in keinem Bauplan verzeichnet sind. Beide sind leer, trocken und ohne Zugang von innen.

Die Verwaltung hat eine zweite Begehung angesetzt. Ein Termin steht noch nicht fest.`,
  },
  {
    id: 'seed-429',
    kicker: 'Kurz',
    title: 'Der Lüfter läuft wieder',
    sector: 'Sektor 11',
    created_at: '2186-03-02T09:05:00.000Z',
    lead: 'Nach sechs Wochen Stillstand ist die Belüftung zurück im Betrieb.',
    body: `Ersatzteil eingetroffen, eingebaut, funktioniert. Mehr gibt es dazu nicht zu sagen.`,
  },
];
