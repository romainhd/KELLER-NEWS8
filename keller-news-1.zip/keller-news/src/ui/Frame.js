import React from 'react';
import { View, StyleSheet } from 'react-native';
import { C } from '../theme';

// Signatur der App: ein hauchdünner Cockpit-Rahmen mit Eckwinkeln,
// der über allem liegt. Reagiert auf nichts, sagt nur: du siehst durch ein Gerät.
export default function Frame() {
  return (
    <View pointerEvents="none" style={StyleSheet.absoluteFill}>
      <View style={s.edge} />
      <View style={[s.corner, s.tl]} />
      <View style={[s.corner, s.tr]} />
      <View style={[s.corner, s.bl]} />
      <View style={[s.corner, s.br]} />
    </View>
  );
}

const INSET = 6;
const LEN = 22;

const s = StyleSheet.create({
  edge: {
    position: 'absolute',
    top: INSET,
    left: INSET,
    right: INSET,
    bottom: INSET,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: C.hairline,
  },
  corner: {
    position: 'absolute',
    width: LEN,
    height: LEN,
    borderColor: C.hairlineHi,
  },
  tl: { top: INSET, left: INSET, borderTopWidth: 1, borderLeftWidth: 1 },
  tr: { top: INSET, right: INSET, borderTopWidth: 1, borderRightWidth: 1 },
  bl: { bottom: INSET, left: INSET, borderBottomWidth: 1, borderLeftWidth: 1 },
  br: { bottom: INSET, right: INSET, borderBottomWidth: 1, borderRightWidth: 1 },
});
