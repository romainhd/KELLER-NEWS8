import AsyncStorage from '@react-native-async-storage/async-storage';
import { SUPABASE_URL, SUPABASE_ANON_KEY, isLive } from './config';

const KEY = 'keller.session';

// ── Anmelden ────────────────────────────────────────────────
export async function signIn(email, password) {
  if (!isLive()) {
    if (password !== 'keller') throw new Error('Zugang verweigert');
    const demo = { token: 'demo-token', email: email.trim() || 'redaktion' };
    await AsyncStorage.setItem(KEY, JSON.stringify(demo));
    return demo;
  }

  const res = await fetch(
    `${SUPABASE_URL}/auth/v1/token?grant_type=password`,
    {
      method: 'POST',
      headers: {
        apikey: SUPABASE_ANON_KEY,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ email: email.trim(), password }),
    }
  );

  if (!res.ok) throw new Error('Zugang verweigert');
  const json = await res.json();

  const session = {
    token: json.access_token,
    refresh: json.refresh_token,
    email: json.user?.email,
    expires: Date.now() + (json.expires_in || 3600) * 1000,
  };
  await AsyncStorage.setItem(KEY, JSON.stringify(session));
  return session;
}

// ── Abmelden ────────────────────────────────────────────────
export async function signOut() {
  await AsyncStorage.removeItem(KEY);
}

// ── Gespeicherte Sitzung zurückholen ────────────────────────
export async function restoreSession() {
  const raw = await AsyncStorage.getItem(KEY);
  if (!raw) return null;

  let session;
  try {
    session = JSON.parse(raw);
  } catch {
    return null;
  }

  if (!isLive()) return session;

  // Token noch gültig?
  if (session.expires && session.expires > Date.now() + 60000) return session;

  // Sonst erneuern.
  if (!session.refresh) return null;
  try {
    const res = await fetch(
      `${SUPABASE_URL}/auth/v1/token?grant_type=refresh_token`,
      {
        method: 'POST',
        headers: {
          apikey: SUPABASE_ANON_KEY,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ refresh_token: session.refresh }),
      }
    );
    if (!res.ok) throw new Error('abgelaufen');
    const json = await res.json();
    const next = {
      token: json.access_token,
      refresh: json.refresh_token,
      email: json.user?.email,
      expires: Date.now() + (json.expires_in || 3600) * 1000,
    };
    await AsyncStorage.setItem(KEY, JSON.stringify(next));
    return next;
  } catch {
    await AsyncStorage.removeItem(KEY);
    return null;
  }
}
