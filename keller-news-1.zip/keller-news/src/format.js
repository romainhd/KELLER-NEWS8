const p = (n) => String(n).padStart(2, '0');

export const fmtDate = (iso) => {
  const d = new Date(iso);
  if (isNaN(d)) return '';
  return `${p(d.getDate())}.${p(d.getMonth() + 1)}.${d.getFullYear()}`;
};

export const fmtStamp = (iso) => {
  const d = new Date(iso);
  if (isNaN(d)) return '';
  return `${p(d.getDate())}.${p(d.getMonth() + 1)}. ${p(d.getHours())}:${p(d.getMinutes())}`;
};

export const shortId = (id) => String(id).slice(-4).toUpperCase();

export const paragraphs = (text) =>
  String(text || '')
    .split(/\n\s*\n/)
    .map((s) => s.trim())
    .filter(Boolean);
