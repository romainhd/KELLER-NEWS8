import { Platform } from 'react-native';

// KELLER NEWS — Farbwelt: kaltes Schwarz, Panzerstahl, Holo-Blau, oxidiertes Rot, Signalgold.
export const C = {
  void: '#08090B',
  panel: '#101317',
  panelHi: '#161A20',
  hairline: '#23282F',
  hairlineHi: '#39414B',
  text: '#C9D1D9',
  textDim: '#6B747E',
  holo: '#6FB7D6',
  alert: '#C8452C',
  crawl: '#E8C547',
};

export const MONO = Platform.select({
  ios: 'Menlo',
  android: 'monospace',
  default: 'monospace',
});

export const SANS = Platform.select({
  ios: 'Helvetica Neue',
  android: 'sans-serif',
  default: 'System',
});

export const SANS_MEDIUM = Platform.select({
  ios: 'Helvetica Neue',
  android: 'sans-serif-medium',
  default: 'System',
});

export const S = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 40,
};

// Weit gesperrte Versalien — die Stimme des Senders.
export const display = (size, color = C.text) => ({
  fontFamily: SANS_MEDIUM,
  fontSize: size,
  lineHeight: size * 1.15,
  letterSpacing: size * 0.14,
  color,
  textTransform: 'uppercase',
  fontWeight: Platform.OS === 'ios' ? '600' : 'normal',
});

// Monospace-Datenzeile — IDs, Zeitstempel, Sektoren.
export const data = (size = 11, color = C.textDim) => ({
  fontFamily: MONO,
  fontSize: size,
  letterSpacing: 1.6,
  color,
  textTransform: 'uppercase',
});

export const body = (size = 16, color = C.text) => ({
  fontFamily: SANS,
  fontSize: size,
  lineHeight: size * 1.6,
  color,
});
