import { SUPABASE_URL, isLive, restHeaders } from './config';
import { SEED_POSTS } from './posts';

// Demo-Speicher: läuft ohne Backend, verschwindet beim Schließen der App.
const demoPosts = SEED_POSTS.map((p) => ({ ...p }));
const demoComments = {};

const fail = (res) => {
  throw new Error(`Relais antwortet mit ${res.status}`);
};

// ── Meldungen ───────────────────────────────────────────────

export async function loadPosts() {
  if (!isLive()) return demoPosts.map((p) => ({ ...p }));

  const res = await fetch(
    `${SUPABASE_URL}/rest/v1/posts?select=*&order=created_at.desc`,
    { headers: restHeaders() }
  );
  if (!res.ok) fail(res);
  return res.json();
}

export async function createPost(token, draft) {
  const row = {
    kicker: draft.kicker.trim() || 'Meldung',
    title: draft.title.trim(),
    sector: draft.sector.trim(),
    lead: draft.lead.trim(),
    body: draft.body.trim(),
  };

  if (!isLive()) {
    const local = {
      ...row,
      id: `demo-${Date.now()}`,
      created_at: new Date().toISOString(),
    };
    demoPosts.unshift(local);
    return local;
  }

  const res = await fetch(`${SUPABASE_URL}/rest/v1/posts`, {
    method: 'POST',
    headers: restHeaders(token),
    body: JSON.stringify(row),
  });
  if (!res.ok) fail(res);
  return (await res.json())[0];
}

export async function updatePost(token, id, draft) {
  const row = {
    kicker: draft.kicker.trim() || 'Meldung',
    title: draft.title.trim(),
    sector: draft.sector.trim(),
    lead: draft.lead.trim(),
    body: draft.body.trim(),
  };

  if (!isLive()) {
    const i = demoPosts.findIndex((p) => p.id === id);
    if (i >= 0) demoPosts[i] = { ...demoPosts[i], ...row };
    return demoPosts[i];
  }

  const res = await fetch(
    `${SUPABASE_URL}/rest/v1/posts?id=eq.${encodeURIComponent(id)}`,
    { method: 'PATCH', headers: restHeaders(token), body: JSON.stringify(row) }
  );
  if (!res.ok) fail(res);
  return (await res.json())[0];
}

export async function deletePost(token, id) {
  if (!isLive()) {
    const i = demoPosts.findIndex((p) => p.id === id);
    if (i >= 0) demoPosts.splice(i, 1);
    return;
  }

  const res = await fetch(
    `${SUPABASE_URL}/rest/v1/posts?id=eq.${encodeURIComponent(id)}`,
    { method: 'DELETE', headers: restHeaders(token) }
  );
  if (!res.ok) fail(res);
}

// ── Kommentare (weiterhin ohne Login) ───────────────────────

export async function loadComments(postId) {
  if (!isLive()) return demoComments[postId] ? [...demoComments[postId]] : [];

  const res = await fetch(
    `${SUPABASE_URL}/rest/v1/comments` +
      `?post_id=eq.${encodeURIComponent(postId)}` +
      `&select=id,name,text,created_at&order=created_at.asc`,
    { headers: restHeaders() }
  );
  if (!res.ok) fail(res);
  return res.json();
}

export async function sendComment(postId, name, text) {
  const entry = {
    post_id: postId,
    name: name.trim().slice(0, 40) || 'Anonym',
    text: text.trim().slice(0, 1200),
  };

  if (!isLive()) {
    const local = {
      ...entry,
      id: `demo-${Date.now()}`,
      created_at: new Date().toISOString(),
    };
    demoComments[postId] = [...(demoComments[postId] || []), local];
    return local;
  }

  const res = await fetch(`${SUPABASE_URL}/rest/v1/comments`, {
    method: 'POST',
    headers: restHeaders(),
    body: JSON.stringify(entry),
  });
  if (!res.ok) fail(res);
  return (await res.json())[0];
}

export async function deleteComment(token, id) {
  if (!isLive()) {
    Object.keys(demoComments).forEach((k) => {
      demoComments[k] = demoComments[k].filter((c) => c.id !== id);
    });
    return;
  }

  const res = await fetch(
    `${SUPABASE_URL}/rest/v1/comments?id=eq.${encodeURIComponent(id)}`,
    { method: 'DELETE', headers: restHeaders(token) }
  );
  if (!res.ok) fail(res);
}
