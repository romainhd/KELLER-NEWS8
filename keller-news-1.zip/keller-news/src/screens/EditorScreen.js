import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  Pressable,
  ScrollView,
  StyleSheet,
  Alert,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useApp } from '../store';
import { createPost, updatePost, deletePost } from '../api';
import { C, S, MONO, display, data, body } from '../theme';

const empty = { kicker: '', title: '', sector: '', lead: '', body: '' };

export default function EditorScreen({ route, navigation }) {
  const insets = useSafeAreaInsets();
  const { session, getPost, refresh } = useApp();
  const editId = route.params?.id;
  const existing = editId ? getPost(editId) : null;

  const [draft, setDraft] = useState(
    existing
      ? {
          kicker: existing.kicker || '',
          title: existing.title || '',
          sector: existing.sector || '',
          lead: existing.lead || '',
          body: existing.body || '',
        }
      : empty
  );
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);

  const set = (k) => (v) => setDraft((d) => ({ ...d, [k]: v }));
  const ready = draft.title.trim() && draft.body.trim();

  const save = async () => {
    if (!ready || busy) return;
    setBusy(true);
    setError(null);
    try {
      if (editId) await updatePost(session.token, editId, draft);
      else await createPost(session.token, draft);
      await refresh();
      navigation.navigate('Feed');
    } catch {
      setError('Nicht gespeichert. Verbindung prüfen und erneut senden.');
      setBusy(false);
    }
  };

  const remove = () => {
    Alert.alert(
      'Meldung löschen',
      'Die Meldung und ihre Kommentare verschwinden dauerhaft.',
      [
        { text: 'Abbrechen', style: 'cancel' },
        {
          text: 'Löschen',
          style: 'destructive',
          onPress: async () => {
            try {
              await deletePost(session.token, editId);
              await refresh();
              navigation.navigate('Feed');
            } catch {
              setError('Löschen fehlgeschlagen. Erneut versuchen.');
            }
          },
        },
      ]
    );
  };

  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor: C.void }}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <View style={[s.bar, { paddingTop: insets.top + S.sm }]}>
        <Pressable onPress={() => navigation.goBack()} hitSlop={12}>
          <Text style={data(11, C.holo)}>← Abbrechen</Text>
        </Pressable>
        <Text style={data(10, C.textDim)}>
          {editId ? 'Bearbeiten' : 'Neue Meldung'}
        </Text>
      </View>

      <ScrollView
        contentContainerStyle={{
          padding: S.lg,
          paddingBottom: insets.bottom + S.xl,
        }}
        keyboardShouldPersistTaps="handled"
      >
        <Field label="Rubrik" hint="Meldung · Protokoll · Kurz">
          <TextInput
            value={draft.kicker}
            onChangeText={set('kicker')}
            placeholder="Meldung"
            placeholderTextColor={C.textDim}
            style={s.input}
          />
        </Field>

        <Field label="Überschrift">
          <TextInput
            value={draft.title}
            onChangeText={set('title')}
            placeholder="Worum geht es?"
            placeholderTextColor={C.textDim}
            style={[s.input, s.inputTitle]}
            multiline
          />
        </Field>

        <Field label="Sektor">
          <TextInput
            value={draft.sector}
            onChangeText={set('sector')}
            placeholder="Sektor 07"
            placeholderTextColor={C.textDim}
            style={s.input}
          />
        </Field>

        <Field label="Vorspann" hint="Ein bis zwei Sätze, stehen in der Liste">
          <TextInput
            value={draft.lead}
            onChangeText={set('lead')}
            placeholder="Die kürzeste Fassung der Geschichte."
            placeholderTextColor={C.textDim}
            style={[s.input, s.inputLead]}
            multiline
          />
        </Field>

        <Field label="Text" hint="Leerzeile trennt die Absätze">
          <TextInput
            value={draft.body}
            onChangeText={set('body')}
            placeholder="Der vollständige Bericht."
            placeholderTextColor={C.textDim}
            style={[s.input, s.inputBody]}
            multiline
          />
        </Field>

        {error && <Text style={[body(14, C.alert), s.error]}>{error}</Text>}

        <Pressable
          onPress={save}
          disabled={!ready || busy}
          style={({ pressed }) => [
            s.button,
            (!ready || busy) && s.buttonOff,
            pressed && s.buttonPressed,
          ]}
        >
          <Text style={data(11, ready ? C.crawl : C.textDim)}>
            {busy ? 'Wird gesendet…' : 'Veröffentlichen'}
          </Text>
        </Pressable>

        {editId && (
          <Pressable onPress={remove} style={s.delete} hitSlop={8}>
            <Text style={data(11, C.alert)}>Meldung löschen</Text>
          </Pressable>
        )}
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

function Field({ label, hint, children }) {
  return (
    <View style={s.field}>
      <View style={s.fieldHead}>
        <Text style={data(10, C.text)}>{label}</Text>
        {hint ? <Text style={data(9, C.textDim)}>{hint}</Text> : null}
      </View>
      {children}
    </View>
  );
}

const s = StyleSheet.create({
  bar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: S.lg,
    paddingBottom: S.sm,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: C.hairline,
  },
  field: { marginBottom: S.lg },
  fieldHead: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
    marginBottom: S.sm,
  },
  input: {
    fontFamily: MONO,
    fontSize: 14,
    color: C.text,
    backgroundColor: C.panel,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: C.hairline,
    paddingHorizontal: S.md,
    paddingVertical: S.sm + 4,
  },
  inputTitle: { fontSize: 17, minHeight: 64, textAlignVertical: 'top' },
  inputLead: { minHeight: 72, textAlignVertical: 'top' },
  inputBody: { minHeight: 220, textAlignVertical: 'top' },
  error: { marginBottom: S.sm },
  button: {
    alignItems: 'center',
    paddingVertical: S.md,
    borderWidth: 1,
    borderColor: C.crawl,
  },
  buttonOff: { borderColor: C.hairline },
  buttonPressed: { backgroundColor: C.panelHi },
  delete: { alignItems: 'center', paddingVertical: S.lg },
});
