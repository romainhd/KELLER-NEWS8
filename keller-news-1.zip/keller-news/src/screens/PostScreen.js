import React from 'react';
import {
  View,
  Text,
  ScrollView,
  Pressable,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useApp } from '../store';
import { fmtDate, shortId, paragraphs } from '../format';
import Comments from '../components/Comments';
import { C, S, display, data, body } from '../theme';

export default function PostScreen({ route, navigation }) {
  const insets = useSafeAreaInsets();
  const { getPost, isAdmin } = useApp();
  const post = getPost(route.params.id);

  if (!post) {
    return (
      <View style={[s.missing, { paddingTop: insets.top + S.xl }]}>
        <Text style={data(11, C.alert)}>Meldung nicht im Archiv</Text>
        <Text style={[body(16, C.textDim), s.missingText]}>
          Diese Kennung existiert nicht mehr. Zurück zur Übersicht.
        </Text>
        <Pressable onPress={() => navigation.navigate('Feed')}>
          <Text style={[data(11, C.holo), s.missingLink]}>← Übersicht</Text>
        </Pressable>
      </View>
    );
  }

  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor: C.void }}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <View style={[s.bar, { paddingTop: insets.top + S.sm }]}>
        <Pressable
          onPress={() => navigation.goBack()}
          hitSlop={12}
          style={({ pressed }) => pressed && { opacity: 0.5 }}
        >
          <Text style={data(11, C.holo)}>← Keller News</Text>
        </Pressable>
        {isAdmin ? (
          <Pressable
            onPress={() => navigation.navigate('Editor', { id: post.id })}
            hitSlop={12}
          >
            <Text style={data(10, C.crawl)}>Bearbeiten</Text>
          </Pressable>
        ) : (
          <Text style={data(10, C.textDim)}>{post.sector}</Text>
        )}
      </View>

      <ScrollView
        contentContainerStyle={{ paddingBottom: insets.bottom + S.xl }}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        <View style={s.head}>
          <Text style={data(10, C.alert)}>{post.kicker}</Text>
          <Text style={[display(26), s.title]}>{post.title}</Text>
          <View style={s.rule} />
          <Text style={data(10, C.textDim)}>
            KN-{shortId(post.id)} · {fmtDate(post.created_at)}
            {post.sector ? ` · ${post.sector}` : ''}
          </Text>
        </View>

        <View style={s.article}>
          {!!post.lead && (
            <Text style={[body(17, C.crawl), s.lead]}>{post.lead}</Text>
          )}
          {paragraphs(post.body).map((p, i) => (
            <Text key={i} style={[body(16), s.para]}>
              {p}
            </Text>
          ))}
        </View>

        <Comments postId={post.id} />
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const s = StyleSheet.create({
  bar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: S.lg,
    paddingBottom: S.sm,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: C.hairline,
    backgroundColor: C.void,
  },
  head: { paddingHorizontal: S.lg, paddingTop: S.xl },
  title: { marginTop: S.md },
  rule: { height: 1, backgroundColor: C.hairlineHi, marginVertical: S.md },
  article: { paddingHorizontal: S.lg, paddingTop: S.lg },
  lead: { marginBottom: S.lg },
  para: { marginBottom: S.md },
  missing: { flex: 1, backgroundColor: C.void, paddingHorizontal: S.lg },
  missingText: { marginTop: S.md },
  missingLink: { marginTop: S.lg },
});
