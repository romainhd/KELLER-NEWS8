import React from 'react';
import {
  View,
  Text,
  Image,
  ScrollView,
  Pressable,
  ActivityIndicator,
  RefreshControl,
  StyleSheet,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useApp } from '../store';
import { fmtDate, shortId } from '../format';
import { C, S, display, data, body } from '../theme';

export default function FeedScreen({ navigation }) {
  const insets = useSafeAreaInsets();
  const { posts, status, refresh, isAdmin, session, logout } = useApp();

  return (
    <ScrollView
      style={{ backgroundColor: C.void }}
      contentContainerStyle={{ paddingBottom: insets.bottom + S.xl }}
      showsVerticalScrollIndicator={false}
      refreshControl={
        <RefreshControl
          refreshing={status === 'loading' && posts.length > 0}
          onRefresh={refresh}
          tintColor={C.holo}
        />
      }
    >
      {/* Kopfbild — austauschbar unter assets/header.jpg */}
      <View style={s.hero}>
        <Image
          source={require('../../assets/header.jpg')}
          style={s.heroImage}
          resizeMode="cover"
        />
        <View style={s.scrim} />
        <View style={[s.mast, { paddingTop: insets.top + S.lg }]}>
          <Text style={data(10, C.holo)}>Übertragung offen</Text>
          {/* Langer Druck auf den Titel öffnet die Redaktion. */}
          <Pressable
            onLongPress={() => !isAdmin && navigation.navigate('Login')}
            delayLongPress={700}
          >
            <Text style={[display(30, C.crawl), s.mastTitle]}>
              Keller{'\n'}News
            </Text>
          </Pressable>
          <View style={s.mastRule} />
          <Text style={data(10, C.textDim)}>
            {status === 'ready' ? `${posts.length} Meldungen` : 'Empfang läuft'}
          </Text>
        </View>
      </View>

      {isAdmin && (
        <View style={s.admin}>
          <View>
            <Text style={data(10, C.crawl)}>Redaktion angemeldet</Text>
            <Text style={data(9, C.textDim)}>{session?.email || 'redaktion'}</Text>
          </View>
          <View style={s.adminActions}>
            <Pressable onPress={logout} hitSlop={10}>
              <Text style={data(10, C.textDim)}>Abmelden</Text>
            </Pressable>
            <Pressable
              onPress={() => navigation.navigate('Editor')}
              style={({ pressed }) => [s.adminNew, pressed && s.pressed]}
            >
              <Text style={data(10, C.crawl)}>+ Neue Meldung</Text>
            </Pressable>
          </View>
        </View>
      )}

      {status === 'loading' && posts.length === 0 && (
        <View style={s.state}>
          <ActivityIndicator color={C.holo} />
        </View>
      )}

      {status === 'failed' && (
        <View style={s.state}>
          <Text style={body(15, C.alert)}>
            Das Archiv antwortet nicht. Verbindung prüfen.
          </Text>
          <Pressable onPress={refresh} hitSlop={10}>
            <Text style={[data(11, C.holo), s.retry]}>Erneut laden</Text>
          </Pressable>
        </View>
      )}

      {status === 'ready' && posts.length === 0 && (
        <View style={s.state}>
          <Text style={body(15, C.textDim)}>
            Noch nichts gesendet. {isAdmin ? 'Schreib die erste Meldung.' : ''}
          </Text>
        </View>
      )}

      {posts.map((post) => (
        <Pressable
          key={post.id}
          onPress={() => navigation.navigate('Post', { id: post.id })}
          style={({ pressed }) => [s.row, pressed && s.rowPressed]}
        >
          {/* Sensor-Schiene: der Tick markiert eine erfasste Meldung. */}
          <View style={s.rail}>
            <View style={s.railTick} />
            <View style={s.railLine} />
          </View>

          <View style={s.rowBody}>
            <View style={s.metaLine}>
              <Text style={data(10, C.alert)}>{post.kicker}</Text>
              <Text style={data(10, C.textDim)}>
                KN-{shortId(post.id)} · {fmtDate(post.created_at)}
              </Text>
            </View>
            <Text style={[display(19), s.rowTitle]}>{post.title}</Text>
            {!!post.lead && (
              <Text style={body(15, C.textDim)} numberOfLines={2}>
                {post.lead}
              </Text>
            )}
            <Text style={[data(10, C.holo), s.open]}>Lesen →</Text>
          </View>
        </Pressable>
      ))}
    </ScrollView>
  );
}

const s = StyleSheet.create({
  hero: { height: 380, backgroundColor: C.panel },
  heroImage: { ...StyleSheet.absoluteFillObject, opacity: 0.55 },
  scrim: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(8,9,11,0.55)',
  },
  mast: {
    flex: 1,
    justifyContent: 'flex-end',
    paddingHorizontal: S.lg,
    paddingBottom: S.lg,
  },
  mastTitle: { marginTop: S.sm },
  mastRule: { height: 1, backgroundColor: C.hairlineHi, marginVertical: S.md },
  admin: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: S.lg,
    paddingVertical: S.md,
    backgroundColor: C.panel,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: C.hairlineHi,
  },
  adminActions: { flexDirection: 'row', alignItems: 'center', gap: S.md },
  adminNew: {
    borderWidth: 1,
    borderColor: C.crawl,
    paddingHorizontal: S.md,
    paddingVertical: S.sm,
  },
  pressed: { backgroundColor: C.panelHi },
  state: { paddingHorizontal: S.lg, paddingVertical: S.xl },
  retry: { marginTop: S.md },
  row: {
    flexDirection: 'row',
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: C.hairline,
    paddingRight: S.lg,
  },
  rowPressed: { backgroundColor: C.panel },
  rail: { width: S.lg + S.sm, alignItems: 'center', paddingTop: S.lg + 4 },
  railTick: { width: 7, height: 1, backgroundColor: C.alert },
  railLine: { width: 1, flex: 1, backgroundColor: C.hairline, marginTop: 6 },
  rowBody: { flex: 1, paddingVertical: S.lg, paddingLeft: S.sm },
  metaLine: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: S.sm,
  },
  rowTitle: { marginBottom: S.sm },
  open: { marginTop: S.md },
});
