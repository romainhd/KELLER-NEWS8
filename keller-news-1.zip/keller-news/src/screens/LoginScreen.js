import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  Pressable,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useApp } from '../store';
import { isLive } from '../config';
import { C, S, MONO, display, data, body } from '../theme';

export default function LoginScreen({ navigation }) {
  const insets = useSafeAreaInsets();
  const { login } = useApp();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);

  const submit = async () => {
    if (busy || !password) return;
    setBusy(true);
    setError(null);
    try {
      await login(email, password);
      navigation.goBack();
    } catch {
      setError('Zugang verweigert. E-Mail und Passwort prüfen.');
      setBusy(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor: C.void }}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <View style={[s.bar, { paddingTop: insets.top + S.sm }]}>
        <Pressable onPress={() => navigation.goBack()} hitSlop={12}>
          <Text style={data(11, C.holo)}>← Zurück</Text>
        </Pressable>
        <Text style={data(10, C.textDim)}>Gesperrter Bereich</Text>
      </View>

      <View style={s.wrap}>
        <Text style={data(10, C.alert)}>Redaktion</Text>
        <Text style={[display(24), s.title]}>Anmelden</Text>
        <View style={s.rule} />
        <Text style={[body(15, C.textDim), s.hint]}>
          Nur die Redaktion meldet sich an. Lesen und Kommentieren bleibt für
          alle offen.
        </Text>

        <TextInput
          value={email}
          onChangeText={setEmail}
          placeholder="E-Mail"
          placeholderTextColor={C.textDim}
          autoCapitalize="none"
          keyboardType="email-address"
          style={s.input}
        />
        <TextInput
          value={password}
          onChangeText={setPassword}
          placeholder="Passwort"
          placeholderTextColor={C.textDim}
          secureTextEntry
          autoCapitalize="none"
          style={s.input}
          onSubmitEditing={submit}
        />

        {error && <Text style={[body(14, C.alert), s.error]}>{error}</Text>}

        <Pressable
          onPress={submit}
          disabled={!password || busy}
          style={({ pressed }) => [
            s.button,
            (!password || busy) && s.buttonOff,
            pressed && s.buttonPressed,
          ]}
        >
          <Text style={data(11, password ? C.crawl : C.textDim)}>
            {busy ? 'Prüfe…' : 'Anmelden'}
          </Text>
        </Pressable>

        {!isLive() && (
          <Text style={[data(9, C.textDim), s.demo]}>
            Demo-Modus · Passwort "keller"
          </Text>
        )}
      </View>
    </KeyboardAvoidingView>
  );
}

const s = StyleSheet.create({
  bar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: S.lg,
    paddingBottom: S.sm,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: C.hairline,
  },
  wrap: { paddingHorizontal: S.lg, paddingTop: S.xl },
  title: { marginTop: S.md },
  rule: { height: 1, backgroundColor: C.hairlineHi, marginVertical: S.md },
  hint: { marginBottom: S.lg },
  input: {
    fontFamily: MONO,
    fontSize: 14,
    color: C.text,
    backgroundColor: C.panel,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: C.hairline,
    paddingHorizontal: S.md,
    paddingVertical: S.sm + 4,
    marginBottom: S.sm,
  },
  error: { marginTop: S.sm, marginBottom: S.sm },
  button: {
    alignItems: 'center',
    paddingVertical: S.md,
    borderWidth: 1,
    borderColor: C.crawl,
    marginTop: S.md,
  },
  buttonOff: { borderColor: C.hairline },
  buttonPressed: { backgroundColor: C.panelHi },
  demo: { marginTop: S.md, textAlign: 'center' },
});
